import { pgTable, serial, text, integer, timestamp, varchar, boolean, foreignKey } from 'drizzle-orm/pg-core';

export const loanRequests = pgTable('loan_requests', {
  id: serial('id').primaryKey(),
  fullName: text('full_name').notNull(),
  email: text('email').notNull(),
  loanAmount: integer('loan_amount').notNull(),
  purpose: text('purpose').notNull(),
  status: varchar('status', { length: 20 }).notNull(),
  createdAt: timestamp('created_at').notNull().defaultNow(),
});

export const verifications = pgTable('verifications', {
  id: serial('id').primaryKey(),
  loanId: integer('loan_id').notNull().references(() => loanRequests.id),
  cibilScore: integer('cibil_score').notNull(),
  verificationNotes: text('verification_notes').notNull(),
  isApproved: boolean('is_approved').notNull(),
  createdAt: timestamp('created_at').notNull().defaultNow(),
});

export const approvals = pgTable('approvals', {
  id: serial('id').primaryKey(),
  loanId: integer('loan_id').notNull().references(() => loanRequests.id),
  approvalNotes: text('approval_notes').notNull(),
  isApproved: boolean('is_approved').notNull(),
  disbursementAmount: integer('disbursement_amount'),
  createdAt: timestamp('created_at').notNull().defaultNow(),
});