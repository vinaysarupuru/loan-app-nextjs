export interface LoanRequest {
    id: number;
    fullName: string;
    email: string;
    loanAmount: number;
    purpose: string;
    status: string;
    createdAt: Date;
  }
  
  export interface Verification {
    id: number;
    loanId: number;
    cibilScore: number;
    verificationNotes: string;
    isApproved: boolean;
    createdAt: Date;
  }
  
  export interface Approval {
    id: number;
    loanId: number;
    approvalNotes: string;
    isApproved: boolean;
    disbursementAmount: number | null;
    createdAt: Date;
  }