'use server';

import { z } from 'zod';
import { db } from '../db';
import { loanRequests, verifications, approvals } from '../schema';
import { eq } from 'drizzle-orm';
import { generateLoanApprovalEmail } from '../email';
import { generateLoanDetailsPDF } from '../pdf';

const loanRequestSchema = z.object({
  fullName: z.string(),
  email: z.string().email(),
  loanAmount: z.number(),
  purpose: z.string(),
});

export async function submitLoanRequest(data: z.infer<typeof loanRequestSchema>) {
  const validatedData = loanRequestSchema.parse(data);
  
  const [newLoan] = await db.insert(loanRequests).values({
    ...validatedData,
    status: 'PENDING',
    createdAt: new Date(),
  }).returning();

  return newLoan;
}

const verificationSchema = z.object({
  loanId: z.number(),
  cibilScore: z.number(),
  verificationNotes: z.string(),
  isApproved: z.boolean(),
});

export async function submitVerification(data: z.infer<typeof verificationSchema>) {
  const validatedData = verificationSchema.parse(data);
  
  const [newVerification] = await db.insert(verifications).values({
    ...validatedData,
    createdAt: new Date(),
  }).returning();

  await db.update(loanRequests)
    .set({ status: validatedData.isApproved ? 'VERIFIED' : 'REJECTED' })
    .where(eq(loanRequests.id, validatedData.loanId));

  return newVerification;
}

const approvalSchema = z.object({
  loanId: z.number(),
  approvalNotes: z.string(),
  isApproved: z.boolean(),
  disbursementAmount: z.number().optional(),
});

export async function submitApproval(data: z.infer<typeof approvalSchema>) {
  const validatedData = approvalSchema.parse(data);
  
  const [newApproval] = await db.insert(approvals).values({
    ...validatedData,
    createdAt: new Date(),
  }).returning();

  await db.update(loanRequests)
    .set({ status: validatedData.isApproved ? 'APPROVED' : 'REJECTED' })
    .where(eq(loanRequests.id, validatedData.loanId));

  if (validatedData.isApproved) {
    const loanDetails = await db.select().from(loanRequests).where(eq(loanRequests.id, validatedData.loanId)).limit(1);
    const pdfBuffer = await generateLoanDetailsPDF(loanDetails[0]);
    await generateLoanApprovalEmail(loanDetails[0].email, pdfBuffer);
  }

  return newApproval;
}