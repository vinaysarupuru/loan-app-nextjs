import PDFDocument from 'pdfkit';
import { LoanRequest } from './types';

export async function generateLoanDetailsPDF(loanDetails: LoanRequest): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument();
    const chunks: Buffer[] = [];

    doc.on('data', (chunk) => chunks.push(chunk));
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    doc.on('error', reject);

    doc
      .fontSize(18)
      .text('Loan Approval Details', { align: 'center' })
      .moveDown();

    doc
      .fontSize(12)
      .text(`Loan ID: ${loanDetails.id}`)
      .text(`Full Name: ${loanDetails.fullName}`)
      .text(`Email: ${loanDetails.email}`)
      .text(`Loan Amount: $${loanDetails.loanAmount}`)
      .text(`Purpose: ${loanDetails.purpose}`)
      .text(`Status: ${loanDetails.status}`)
      .text(`Created At: ${loanDetails.createdAt.toLocaleDateString()}`)
      .moveDown();

    doc
      .fontSize(14)
      .text('Terms and Conditions', { underline: true })
      .moveDown()
      .fontSize(10)
      .text('Please read the following terms and conditions carefully...');

    doc.end();
  });
}