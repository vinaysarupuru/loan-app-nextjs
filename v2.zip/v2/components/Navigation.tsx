import Link from 'next/link';

export function Navigation() {
  return (
    <nav className="bg-gray-800 text-white p-4">
      <ul className="flex space-x-4">
        <li>
          <Link href="/" className="hover:text-gray-300">
            Home
          </Link>
        </li>
        <li>
          <Link href="/loan-request" className="hover:text-gray-300">
            New Loan Request
          </Link>
        </li>
        <li>
          <Link href="/verification" className="hover:text-gray-300">
            Verification
          </Link>
        </li>
        <li>
          <Link href="/approval" className="hover:text-gray-300">
            Approval
          </Link>
        </li>
      </ul>
    </nav>
  );
}